//
//  MapView.swift
//  SwiftUIBegginerProjectLuiz
//
//  Created by Luiz Henrique Monteiro de Carvalho on 25/03/20.
//  Copyright © 2020 Luiz Henrique Monteiro de Carvalho. All rights reserved.
//

import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    
    func makeUIView(context: UIViewRepresentableContext<MapView>) -> MKMapView {
        MKMapView()
    }
    
    func updateUIView(_ uiView: MKMapView, context: UIViewRepresentableContext<MapView>) {
        //codigo para fazer update da uikit view
        //Latitude -23.4583478, Longitude -46.6306827.
        let cordinate = CLLocationCoordinate2D(latitude: -23.588884 , longitude: -46.652792)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: cordinate, span: span)
        uiView.setRegion(region, animated: true)
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}

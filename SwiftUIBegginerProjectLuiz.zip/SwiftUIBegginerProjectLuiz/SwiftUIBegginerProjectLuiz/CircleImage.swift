//
//  CircleImage.swift
//  SwiftUIBegginerProjectLuiz
//
//  Created by Luiz Henrique Monteiro de Carvalho on 25/03/20.
//  Copyright © 2020 Luiz Henrique Monteiro de Carvalho. All rights reserved.
//

import SwiftUI

struct CircleImage: View {
    var body: some View {
        Image("parquinho daora").frame(width: 300, height: 300, alignment: .center)
            .clipShape(Circle())
            .overlay(Circle().stroke().foregroundColor(.white)).shadow(radius: 10)
        
        
    }
}

struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage()
    }
}

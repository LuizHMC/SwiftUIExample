//
//  ContentView.swift
//  SwiftUIBegginerProjectLuiz
//
//  Created by Luiz Henrique Monteiro de Carvalho on 25/03/20.
//  Copyright © 2020 Luiz Henrique Monteiro de Carvalho. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        VStack {
            //view de mapa
            MapView()
                .frame(height: 300).edgesIgnoringSafeArea(.top)
            //View de imagem
            CircleImage()
                .offset(y: -100).padding(.bottom, -100)
            
            
            
            //Views de texto
            VStack(alignment: .leading) {
                Text("Parque Ibirapuera")
                .font(.title)
                HStack{
                    Text("Parquinho Daora")
                        .font(.subheadline)
                    Spacer()
                    Text("São Paulo")
                        .font(.subheadline)
                }
            }.padding()
            
            //spacer
            Spacer()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
